You can place new themes in this folder.

When you generate a new theme, make sure to set the CSS Scope to '.player-ui' within the
Advanced Theme Settings.